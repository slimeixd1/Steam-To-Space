**Whimscape Leaves 1.20_r1** (2023 Jun 07)
- added cherry leaves
- changed azalea flower colors slightly
- changed pack_format to 15

________________________________________________________________

**Whimscape Leaves 1.19.3_r2** (2023 Feb 19)
- changed azalea blocks slightly
- changed pack.png: small tweak


**Whimscape Leaves 1.19.3_r1** (2022 Dec 07)
- changed pack_format to 12

________________________________________________________________

**Whimscape Leaves 1.19_r2** (2023 Feb 19)
- backported changes from 1.19.3_r2


**Whimscape Leaves 1.19_r1** (2022 Oct 01)
- initial release