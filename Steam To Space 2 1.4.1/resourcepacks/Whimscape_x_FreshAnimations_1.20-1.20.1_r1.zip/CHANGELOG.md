**Whimscape x Fresh Animations 1.20-1.20.1_r1** (2024 Mar 14)
- fixed allay, bee, creeper, goat, shulker and sniffer for FA 1.9
- fixed z-fighting in hoglin and zoglin manes
- changed pack_format to 15

________________________________________________________________

**Whimscape x Fresh Animations 1.19.4_r1** (2024 Mar 14)
- fixed allay, bee, creeper, goat and shulker for FA 1.9
- fixed z-fighting in hoglin and zoglin manes
- changed pack_format to 13

________________________________________________________________

**Whimscape x Fresh Animations 1.19.3_r1** (2023 Jun 09)
- fixed vex textures for the new model
- changed horse_creamy colors slightly
- changed pack_format to 12

________________________________________________________________

**Whimscape x Fresh Animations 1.19_r1** (2023 Feb 10)
- initial release